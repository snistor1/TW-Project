create package body apex_mail_p
is
   -- Write a MIME header
   procedure write_mime_header (
      p_conn in out nocopy utl_smtp.connection
    , p_name in varchar2
    , p_value in varchar2
   )
   is
   begin
      utl_smtp.write_data ( p_conn
                          , p_name || ': ' || p_value || utl_tcp.crlf
      );
   end;
   procedure mail (
      p_sender in varchar2
    , p_recipient in varchar2
    , p_subject in varchar2
    , p_message in varchar2
   )
   is
      l_conn           utl_smtp.connection;
      nls_charset    varchar2(255);
   begin
      select value
      into   nls_charset
      from   nls_database_parameters
      where  parameter = 'NLS_CHARACTERSET';  -- establish connection and autheticate
      l_conn   := utl_smtp.open_connection ('localhost', 1925);
      utl_smtp.ehlo(l_conn, 'gmail.com'); 
      utl_smtp.command(l_conn, 'auth login');
      utl_smtp.command(l_conn,utl_encode.text_encode('serbanstol@gmail.com', nls_charset, 1));
      utl_smtp.command(l_conn, utl_encode.text_encode('Iwillremembereverything17524809', nls_charset, 1));

      utl_smtp.command(l_conn, 'MAIL FROM: <'||p_sender||'>');
      utl_smtp.command(l_conn, 'RCPT TO: <'||p_recipient||'>');

      utl_smtp.open_data (l_conn);
      write_mime_header (l_conn, 'From', p_sender);
      write_mime_header (l_conn, 'To', p_recipient);
      write_mime_header (l_conn, 'Subject', p_subject);
      write_mime_header (l_conn, 'Content-Type', 'text/plain');
      utl_smtp.write_data (l_conn, utl_tcp.crlf);
      utl_smtp.write_data (l_conn, p_message);
      utl_smtp.close_data (l_conn);
      utl_smtp.quit (l_conn);
      dbms_output.put_line('MAIL SENT');
   exception
      when others
      then
         begin
           utl_smtp.quit(l_conn);
         exception
           when others then
             null;
         end;
         raise_application_error(-20000,'FAIL');  
   end;
end;
/

