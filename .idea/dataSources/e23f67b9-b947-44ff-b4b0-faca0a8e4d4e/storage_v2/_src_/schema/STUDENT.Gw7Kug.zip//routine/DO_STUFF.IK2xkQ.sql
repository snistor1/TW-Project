create procedure do_stuff(nume_tabel in varchar2) as
    v_fisier UTL_FILE.FILE_TYPE;
    v_cursor_coloane number;
    v_ok_coloane number;
    v_rec_tab dbms_sql.desc_tab3;
    v_nr_col number;
    v_total_coloane number;
    v_tip_returnat varchar2(1000);

    --------------------
    v_cursor_constrangeri number;
    v_ok_constrangeri number;
    v_nr_constrangeri number;
    v_total_constrangeri number;
    v_constrangere varchar2(3000);
    v_coloana_constrangere varchar2(1000);
    v_tip_constrangere varchar2(100);
    v_numar_coloane_constrangere number :=0;
    --------------------
    v_cursor_constrangeri2 number;
    v_ok_constrangeri2 number;
    v_nr_constrangeri2 number;
    v_total_constrangeri2 number;
    v_constrangere2 varchar2(3000);
    v_coloana_constrangere2 varchar2(1000);
    v_tip_constrangere2 varchar2(100);

    --------------------
    v_cursor_foreign number;
    v_ok_foreign number;
    v_nr_foreign number;
    v_total_foreign number;
    v_nume_constrangere_foreign varchar2(1000);
    v_nume_coloana_foreign varchar2(1000);
    v_nume_tabel_referentiat varchar2(1000);
    v_nume_coloana_referentiata varchar2(1000);
    --------------------
    v_cursor_insert number;
    v_ok_insert number;
    v_nr_insert number;
    v_total_insert number;
    v_rec_insert dbms_sql.desc_tab;
    v_data_insert varchar2(3000);

    --------------------
    v_cursor_relatii number;
    v_ok_relatie number;
    v_relatie varchar2(1000);

    v_exista number;
begin

    --verific existenta tabelului
    select count(*) into v_exista from user_tables where upper(table_name)=upper(nume_tabel);
    if v_exista=0 then
        return;
    end if;

    --verific daca are relatii(pentru bonus)
    v_cursor_relatii := dbms_sql.open_cursor;
    dbms_sql.parse(v_cursor_relatii,'select DISTINCT
     a.table_name "Referenced Table"
    from all_constraints a, all_constraints b 
    where 
    b.constraint_type = '||'''R'''||
    ' and a.constraint_name = b.r_constraint_name 
    and b.table_name='''||upper(nume_tabel)||'''' 
    ,dbms_sql.native);
    dbms_sql.define_column(v_cursor_relatii,1,v_relatie,1000);
    v_ok_relatie := dbms_sql.execute(v_cursor_relatii);
    loop
        --o sa apelez recursiv aceasta functie pentru tabelele aflate in relatie cu tabela initiala
        if dbms_sql.fetch_rows(v_cursor_relatii) > 0 then
            dbms_sql.column_value(v_cursor_relatii,1,v_relatie);
            do_stuff(v_relatie);
        else
            exit;
        end if;
    end loop;
    dbms_sql.close_cursor(v_cursor_relatii);

    --incepem distractia
    v_fisier := utl_file.fopen('MYDIR','tabel.sql','A');
    utl_file.put_line(v_fisier,'DROP TABLE '||nume_tabel||' cascade constraints;/');

    v_cursor_coloane := dbms_sql.open_cursor;
    dbms_sql.parse(v_cursor_coloane,'select * from '||nume_tabel,dbms_sql.native);
    v_ok_coloane := dbms_sql.execute(v_cursor_coloane);
    dbms_sql.describe_columns3(v_cursor_coloane,v_total_coloane,v_rec_tab);

    --aici fac create table cu tipurile campurilor
    v_nr_col := v_rec_tab.first;
    if(v_nr_col is not null) then
        utl_file.put(v_fisier,'CREATE TABLE ' ||nume_tabel||'(');
        loop
            if(v_nr_col!=v_rec_tab.first) then
                utl_file.put(v_fisier,',');
            end if;
            utl_file.put(v_fisier,v_rec_tab(v_nr_col).col_name);

            v_tip_returnat := arata_tipul_coloanei(v_rec_tab(v_nr_col).col_type);
            utl_file.put(v_fisier,' '||v_tip_returnat);
            if(v_tip_returnat in ('VARCHAR2','CHAR','VARCHAR')) then
                utl_file.put(v_fisier,'('||v_rec_tab(v_nr_col).col_max_len||')');
            elsif(v_tip_returnat in('NUMBER')) then
                utl_file.put(v_fisier,'('||v_rec_tab(v_nr_col).col_precision||','||v_rec_tab(v_nr_col).col_scale||')');
            end if;
            if(v_rec_tab(v_nr_col).col_null_ok!=True) then
                utl_file.put(v_fisier,' NOT NULL');
            end if;
            v_nr_col := v_rec_tab.next(v_nr_col);
            exit when(v_nr_col is null);
        end loop;
    end if;
    utl_file.put_line(v_fisier,');/');

    --aici iau constrangerile de primary key
    v_cursor_constrangeri := dbms_sql.open_cursor;
    dbms_sql.parse(v_cursor_constrangeri,
    'select distinct a.column_name, u.constraint_type from all_cons_columns a join 
user_constraints u on a.table_name=u.table_name where u.constraint_type in(''P'') and u.constraint_name=a.constraint_name and a.table_name='''||
upper(nume_tabel)||'''',DBMS_SQL.NATIVE);
    dbms_sql.define_column(v_cursor_constrangeri,1,v_coloana_constrangere,1000);
    dbms_sql.define_column(v_cursor_constrangeri,2,v_tip_constrangere,100);
    v_ok_constrangeri := dbms_sql.execute(v_cursor_constrangeri);
    v_numar_coloane_constrangere :=0;
    loop
        if dbms_sql.fetch_rows(v_cursor_constrangeri) > 0 then
            dbms_sql.column_value(v_cursor_constrangeri,1,v_coloana_constrangere);
            dbms_sql.column_value(v_cursor_constrangeri,2,v_tip_constrangere);
            if(v_numar_coloane_constrangere=0) then
                utl_file.put(v_fisier,'ALTER TABLE ' || nume_tabel || ' ADD PRIMARY KEY(' || '"'||v_coloana_constrangere||'"');
            else
                utl_file.put(v_fisier,','||'"'||v_coloana_constrangere||'"');
            end if;
            v_numar_coloane_constrangere := v_numar_coloane_constrangere + 1;
        else 
            exit;
        end if;
    end loop;
    utl_file.put_line(v_fisier,');/');
    dbms_sql.close_cursor(v_cursor_constrangeri);

    --aici iau constrangerile de unique
    v_cursor_constrangeri2 := dbms_sql.open_cursor;
    dbms_sql.parse(v_cursor_constrangeri2,
    'select distinct a.column_name, u.constraint_type from all_cons_columns a join 
user_constraints u on a.table_name=u.table_name where u.constraint_type in(''U'') and u.constraint_name=a.constraint_name and a.table_name='''||
upper(nume_tabel)||'''',DBMS_SQL.NATIVE);
    dbms_sql.define_column(v_cursor_constrangeri2,1,v_coloana_constrangere2,1000);
    dbms_sql.define_column(v_cursor_constrangeri2,2,v_tip_constrangere2,100);
    v_ok_constrangeri2 := dbms_sql.execute(v_cursor_constrangeri2);
    v_numar_coloane_constrangere :=0;
    loop
        if dbms_sql.fetch_rows(v_cursor_constrangeri2) > 0 then
            dbms_sql.column_value(v_cursor_constrangeri2,1,v_coloana_constrangere2);
            dbms_sql.column_value(v_cursor_constrangeri2,2,v_tip_constrangere2);
            if(v_numar_coloane_constrangere=0) then
                utl_file.put(v_fisier,'ALTER TABLE ' || nume_tabel || ' ADD CONSTRAINT "NO_DUPLICATES" UNIQUE(' || '"'||v_coloana_constrangere2||'"');
            else
                utl_file.put(v_fisier,','||'"'||v_coloana_constrangere2||'"');
            end if;
            v_numar_coloane_constrangere := v_numar_coloane_constrangere + 1;
        else 
            exit;
        end if;
    end loop;
    if(v_numar_coloane_constrangere!=0) then
        utl_file.put_line(v_fisier,');/');
    end if;
    dbms_sql.close_cursor(v_cursor_constrangeri2);

    --aici iau constrangerile de foreign
    v_cursor_foreign := dbms_sql.open_cursor;
    dbms_sql.parse(v_cursor_foreign,'SELECT a.constraint_name, a.column_name, c_pk.table_name, b.column_name
  FROM user_cons_columns a
  JOIN user_constraints c ON a.owner = c.owner
       AND a.constraint_name = c.constraint_name
  JOIN user_constraints c_pk ON c.r_owner = c_pk.owner
       AND c.r_constraint_name = c_pk.constraint_name
  JOIN user_cons_columns b ON C_PK.owner = b.owner
       AND  C_PK.CONSTRAINT_NAME = b.constraint_name AND b.POSITION = a.POSITION     
 WHERE c.constraint_type = ''R'' and a.table_name='''||upper(nume_tabel)||'''',DBMS_SQL.native);
    dbms_sql.define_column(v_cursor_foreign,1,v_nume_constrangere_foreign,1000);
    dbms_sql.define_column(v_cursor_foreign,2,v_nume_coloana_foreign,1000);
    dbms_sql.define_column(v_cursor_foreign,3,v_nume_tabel_referentiat,1000);
    dbms_sql.define_column(v_cursor_foreign,4,v_nume_coloana_referentiata,1000);
    v_ok_foreign := dbms_sql.execute(v_cursor_foreign);
    loop
        if dbms_sql.fetch_rows(v_cursor_foreign) > 0 then
            dbms_sql.column_value(v_cursor_foreign,1,v_nume_constrangere_foreign);
            dbms_sql.column_value(v_cursor_foreign,2,v_nume_coloana_foreign);
            dbms_sql.column_value(v_cursor_foreign,3,v_nume_tabel_referentiat);
            dbms_sql.column_value(v_cursor_foreign,4,v_nume_coloana_referentiata);
            utl_file.put_line(v_fisier,'ALTER TABLE '||nume_tabel||' ADD CONSTRAINT '||v_nume_constrangere_foreign||
            ' FOREIGN KEY('||v_nume_coloana_foreign||') REFERENCES '||v_nume_tabel_referentiat||'('||v_nume_coloana_referentiata
            ||');/');
        else 
            exit;
        end if;
    end loop;
    dbms_sql.close_cursor(v_cursor_foreign);

    --aici fac inserturile
    v_cursor_insert := dbms_sql.open_cursor;
    dbms_sql.parse(v_cursor_insert,'select * from '||nume_tabel,dbms_sql.native);
    dbms_sql.describe_columns(v_cursor_insert,v_total_insert,v_rec_insert);
    for i in 1..v_total_insert loop
        dbms_sql.define_column(v_cursor_insert,i,v_data_insert,3000);
    end loop;
    v_ok_insert := dbms_sql.execute(v_cursor_insert);
    loop
        if dbms_sql.fetch_rows(v_cursor_insert) > 0 then
            utl_file.put(v_fisier,'INSERT INTO '||nume_tabel||' values(');
            for i in 1..v_total_insert loop
                if i!=1 then
                    utl_file.put(v_fisier,',');
                end if;
                v_tip_returnat := arata_tipul_coloanei(v_rec_insert(i).col_type);
                dbms_sql.column_value(v_cursor_insert,i,v_data_insert);
                if v_data_insert is null then
                    v_data_insert := 'NULL';
                end if;
                if(v_tip_returnat in ('VARCHAR2','CHAR','VARCHAR','DATE')) then
                    utl_file.put(v_fisier,''''||v_data_insert||'''');
                else
                    utl_file.put(v_fisier,v_data_insert);
                end if;
            end loop;
            utl_file.put_line(v_fisier,');/');
        else
            exit;
        end if;
    end loop;
    dbms_sql.close_cursor(v_cursor_insert);
    utl_file.fclose(v_fisier);
end;
/

