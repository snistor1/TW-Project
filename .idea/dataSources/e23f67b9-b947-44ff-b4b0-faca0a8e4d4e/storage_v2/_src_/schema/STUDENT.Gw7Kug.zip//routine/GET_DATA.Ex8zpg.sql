create procedure get_data as
    cursor lista_tabele is select table_name from user_tables where table_name in('STUDENTI');
    cursor lista_tabele2 is select table_name from user_tables where table_name in('PRIETENI');
    v_fisier UTL_FILE.FILE_TYPE;
    v_coloana varchar2(30);
    de_executat varchar2(1000):='';
    v_ok number(1) := 0;
    type v_rezultat_impresionant is table of varchar2(32000);
    chestie v_rezultat_impresionant := v_rezultat_impresionant();
begin
    v_fisier:=utl_file.fopen('MYDIR','test.txt','W');
    for v_nume_tabel in lista_tabele loop
        UTL_file.put_line(v_fisier,'*****');
        UTL_file.put_line(v_fisier,v_nume_tabel.table_name);
        de_executat :='';
        de_executat:= de_executat || 'select to_char(';
        v_ok := 0;
        for temp in (select column_name FROM all_col_comments WHERE table_name = v_nume_tabel.table_name) loop
        if(v_ok=0) then
            --de_executat := de_executat || 'nvl(';
            de_executat := de_executat || temp.column_name;
            --de_executat := de_executat || ',0)';
            v_ok:=1;
        else
            de_executat := de_executat || '|| ''~'' || ';
            de_executat := de_executat || temp.column_name;
            --de_executat := de_executat || ',0)';
        end if;
        end loop;
        de_executat := de_executat || ') as result from ';
        de_executat := de_executat || v_nume_tabel.table_name;
        --dbms_output.put_line(de_executat);
        execute immediate de_executat bulk collect into chestie;
        --dbms_output.put_line(chestie.count);
        if chestie.count>0 then
            for i in chestie.first..chestie.last loop
                if chestie.exists(i) then
                    select replace(chestie(i),'~~','~0~') into chestie(i) from dual;
                    UTL_file.put_line(v_fisier,to_char(chestie(i)));
                end if;
            end loop;
        end if;
    end loop;
    for v_nume_tabel in lista_tabele2 loop
        UTL_file.put_line(v_fisier,'*****');
        UTL_file.put_line(v_fisier,v_nume_tabel.table_name);
        de_executat :='';
        de_executat:= de_executat || 'select to_char(';
        v_ok := 0;
        for temp in (select column_name FROM all_col_comments WHERE table_name = v_nume_tabel.table_name) loop
        if(v_ok=0) then
            --de_executat := de_executat || 'nvl(';
            de_executat := de_executat || temp.column_name;
            --de_executat := de_executat || ',0)';
            v_ok:=1;
        else
            de_executat := de_executat || '|| ''~'' || ';
            de_executat := de_executat || temp.column_name;
            --de_executat := de_executat || ',0)';
        end if;
        end loop;
        de_executat := de_executat || ') as result from ';
        de_executat := de_executat || v_nume_tabel.table_name;
        --dbms_output.put_line(de_executat);
        execute immediate de_executat bulk collect into chestie;
        --dbms_output.put_line(chestie.count);
        if chestie.count>0 then
            for i in chestie.first..chestie.last loop
                if chestie.exists(i) then
                    select replace(chestie(i),'~~','~0~') into chestie(i) from dual;
                    UTL_file.put_line(v_fisier,to_char(chestie(i)));
                end if;
            end loop;
        end if;
    end loop;
    UTL_FILE.fclose(v_fisier);
end;
/

