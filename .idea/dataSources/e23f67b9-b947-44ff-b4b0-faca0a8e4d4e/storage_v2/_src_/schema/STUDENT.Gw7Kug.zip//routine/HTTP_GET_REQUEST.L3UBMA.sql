create procedure http_get_request(host in varchar2,port in number) as
  conexiune  utl_tcp.connection; 
  ret_val pls_integer; 
BEGIN
  conexiune := utl_tcp.open_connection(remote_host => host,
                               remote_port =>  port,
                               charset     => 'US7ASCII');
  if(conexiune.remote_host is null) then
    dbms_output.put_line('FAIL');
    return;
  end if;
  ret_val := utl_tcp.write_line(conexiune, 'GET/HTTP/1.0');
  ret_val := utl_tcp.write_line(conexiune);
  BEGIN
    LOOP
      dbms_output.put_line(utl_tcp.get_line(conexiune, TRUE));
    END LOOP;
  EXCEPTION
    WHEN utl_tcp.end_of_input THEN
      NULL;
    WHEN OTHERS then
        dbms_output.put_line('FAIL');
  END;
  utl_tcp.close_connection(conexiune);
END;
/

