create function arata_tipul_coloanei(tip in number)
return varchar2 is
begin
    case tip
      when dbms_types.TYPECODE_DATE then return 'DATE';             
      when dbms_types.TYPECODE_NUMBER then return 'NUMBER';           
      when dbms_types.TYPECODE_RAW then return 'RAW';              
      when dbms_types.TYPECODE_CHAR then return 'CHAR';             
      when dbms_types.TYPECODE_VARCHAR then return 'VARCHAR2';         
      when dbms_types.TYPECODE_VARCHAR then return 'VARCHAR';          
      when dbms_types.TYPECODE_MLSLABEL then return 'MLSLABEL';         
      when dbms_types.TYPECODE_BLOB then return 'BLOB';             
      when dbms_types.TYPECODE_BFILE then return 'BFILE';            
      when dbms_types.TYPECODE_CLOB then return 'CLOB';              
      when dbms_types.TYPECODE_CFILE then return 'CFILE';            
      when dbms_types.TYPECODE_TIMESTAMP then return 'TIMESTAMP';            
      when dbms_types.TYPECODE_REF then return 'REF';              
      when dbms_types.TYPECODE_OBJECT then return 'OBJECT';           
      when dbms_types.TYPECODE_VARRAY then return 'VARRAY';                       
      when dbms_types.TYPECODE_TABLE then return 'TABLE';                        
      when dbms_types.TYPECODE_NAMEDCOLLECTION then return 'NAMEDCOLLECTION';  
      when dbms_types.TYPECODE_OPAQUE then return 'OPAQUE';                            
      when dbms_types.TYPECODE_NCHAR then return 'NCHAR';            
      when dbms_types.TYPECODE_NVARCHAR2 then return 'NVARCHAR2';       
      when dbms_types.TYPECODE_NCLOB then return 'NCLOB';                 
      when dbms_types.TYPECODE_BFLOAT then return 'BFLOAT';           
      when dbms_types.TYPECODE_BDOUBLE then return 'BDOUBLE';         
      when dbms_types.TYPECODE_UROWID then return 'UROWID';             
    end case;
end;
/

