create procedure trimite_mail (user_name in varchar2, v_receptor in varchar2, v_subiect in varchar2, v_mesaj in varchar2, pass in varchar2) is
      conexiune utl_smtp.connection;
      nls_charset varchar2(1000);
begin

      select value into nls_charset from   nls_database_parameters where  parameter = 'NLS_CHARACTERSET'; 
      conexiune   := utl_smtp.open_connection ('localhost', 1925);
      utl_smtp.ehlo(conexiune, 'gmail.com'); 
      utl_smtp.command(conexiune, 'AUTH LOGIN');
      --pass := :parola;
      utl_smtp.command(conexiune,utl_encode.text_encode(user_name, nls_charset, 1));
      utl_smtp.command(conexiune, utl_encode.text_encode(pass, nls_charset, 1));

      utl_smtp.command(conexiune, 'MAIL FROM: <'||user_name||'>');
      utl_smtp.command(conexiune, 'RCPT TO: <'||v_receptor||'>');

      utl_smtp.open_data (conexiune);
      utl_smtp.write_data ( conexiune, 'From: ' || user_name || utl_tcp.crlf);
      utl_smtp.write_data ( conexiune, 'To: ' || v_receptor || utl_tcp.crlf);
      utl_smtp.write_data ( conexiune, 'Subject: ' || v_subiect || utl_tcp.crlf);
      utl_smtp.write_data (conexiune, utl_tcp.crlf);
      utl_smtp.write_data (conexiune, v_mesaj);
      utl_smtp.close_data (conexiune);
      utl_smtp.quit (conexiune);
      dbms_output.put_line('MAIL SENT');
   exception
      when others
      then
         begin
           utl_smtp.quit(conexiune);
         exception
           when others then
             null;
         end;
         raise_application_error(-20000,'FAIL');  
end;
/

