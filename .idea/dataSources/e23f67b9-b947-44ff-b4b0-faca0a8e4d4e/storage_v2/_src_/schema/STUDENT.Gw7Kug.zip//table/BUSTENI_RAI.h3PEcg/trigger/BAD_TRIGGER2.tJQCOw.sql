create trigger BAD_TRIGGER2
  before delete
  on BUSTENI_RAI
  declare
    PRAGMA AUTONOMOUS_TRANSACTION;
begin
    insert into busteni_rai values(CURRENT_TIMESTAMP, (select user current_user from dual));
    commit;
    raise_application_error(num=>-20000, msg=>'Not today sir!');
end;
/

