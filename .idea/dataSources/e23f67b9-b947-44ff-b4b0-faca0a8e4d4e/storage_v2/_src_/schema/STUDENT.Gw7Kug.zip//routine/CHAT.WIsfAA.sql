create procedure chat(host in varchar2,port in number,director in varchar2,fisier in varchar2) is
    conexiune UTL_TCP.CONNECTION;
    v_raspuns varchar2(1000):='';
    v_linie varchar2(100);
    v_fisier UTL_FILE.FILE_TYPE;
    retval binary_integer;
begin
    v_fisier := utl_file.fopen(director,fisier,'R');
    conexiune := UTL_TCP.OPEN_CONNECTION(
        REMOTE_HOST   => host,
        REMOTE_PORT   => port,
        TX_TIMEOUT    => 10);

    loop
        begin
        BEGIN
                WHILE UTL_TCP.AVAILABLE(conexiune, 10) > 0 LOOP
                    v_raspuns := UTL_TCP.GET_LINE(conexiune,TRUE);
                END LOOP;
                EXCEPTION
                WHEN UTL_TCP.END_OF_INPUT THEN
                    NULL;
            END;
        if(length(v_raspuns)>0) then
            DBMS_OUTPUT.PUT_LINE('De la server: ' || v_raspuns);
        end if;
        v_raspuns := '';
        utl_file.get_line(v_fisier,v_linie);
        dbms_output.put_line('Din fisier: ' || v_linie);
        RETVAL := UTL_TCP.WRITE_LINE(conexiune,v_linie);
        UTL_TCP.FLUSH(conexiune);
        /*BEGIN
                WHILE UTL_TCP.AVAILABLE(conexiune, 10) > 0 LOOP
                    v_raspuns := UTL_TCP.GET_LINE(conexiune,TRUE);
                END LOOP;
                EXCEPTION
                WHEN UTL_TCP.END_OF_INPUT THEN
                    NULL;
            END;
        if(length(v_raspuns)>0) then
            DBMS_OUTPUT.PUT_LINE('De la server: ' || v_raspuns);
        end if;
        v_raspuns := '';*/
        EXCEPTION 
            WHEN No_Data_Found THEN EXIT;

        end;
    end loop;
    utl_file.fclose(v_fisier);
    loop
    RETVAL := UTL_TCP.WRITE_LINE(conexiune,'');
    UTL_TCP.FLUSH(conexiune);
        BEGIN
            WHILE UTL_TCP.AVAILABLE(conexiune, 10) > 0 LOOP
                v_raspuns := UTL_TCP.GET_LINE(conexiune,TRUE);
            END LOOP;
            EXCEPTION
            WHEN UTL_TCP.END_OF_INPUT THEN
                NULL;
        END;
        if(length(v_raspuns)>0) then
            DBMS_OUTPUT.PUT_LINE('De la server: ' || v_raspuns);
        else
            exit;
        end if;
    end loop;
    UTL_TCP.CLOSE_CONNECTION(conexiune);
end;
/

