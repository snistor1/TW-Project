create trigger STERGE_PARCHETAR
  instead of delete
  on CONEXIUNE_MAGICA
  for each row
  begin
    delete from unelte where ID_POSESOR=:old.id_parchetar;
    delete from parchetari where id_parchetar=:old.id_parchetar;
end;
/

