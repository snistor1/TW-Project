create procedure put_data as
    v_fisier UTL_FILE.FILE_TYPE;
    v_sir varchar2(3000);
    v_ok number(1) :=0;
    v_nume_tabel varchar2(10);
begin
    v_fisier:=utl_file.fopen('MYDIR','test.txt','R');
    loop
        begin
        UTL_file.get_line(v_fisier,v_sir);
        if(v_sir like 'STUDENTI' or v_sir like'PRIETENI') then
            v_ok:=1;
            if(v_sir like 'STUDENTI') then
                v_nume_tabel:='S';
            else
                v_nume_tabel:='P';
            end if;
            --DBMS_OUTPUT.PUT_LINE(v_sir);
        elsif(v_ok=1 and v_sir not like '*****') then
            --DBMS_OUTPUT.PUT_LINE(v_sir);
            if(v_nume_tabel like 'S') then
                declare
                    v1 studenti.id%type;
                    v2 studenti.nr_matricol%type;
                    v3 studenti.nume%type;
                    v4 studenti.prenume%type;
                    v5 studenti.an%type;
                    v6 studenti.grupa%type;
                    v7 studenti.bursa%type;
                    v8 studenti.data_nastere%type;
                    v9 studenti.email%type;
                    v10 studenti.created_at%type;
                    v11 studenti.updated_at%type;
                begin
                    SELECT REGEXP_SUBSTR ( v_sir , '[^~]+' , 1 , 1 ) 
                     , REGEXP_SUBSTR ( v_sir , '[^~]+' , 1 , 2 ) 
                     , REGEXP_SUBSTR ( v_sir , '[^~]+' , 1 , 3 ) 
                     , REGEXP_SUBSTR ( v_sir , '[^~]+' , 1 , 4 )
                     , REGEXP_SUBSTR ( v_sir , '[^~]+' , 1 , 5 )
                     , REGEXP_SUBSTR ( v_sir , '[^~]+' , 1 , 6 )
                     , REGEXP_SUBSTR ( v_sir , '[^~]+' , 1 , 7 )
                     , REGEXP_SUBSTR ( v_sir , '[^~]+' , 1 , 8 )
                     , REGEXP_SUBSTR ( v_sir , '[^~]+' , 1 , 9 )
                     , REGEXP_SUBSTR ( v_sir , '[^~]+' , 1 , 10 )
                     , REGEXP_SUBSTR ( v_sir , '[^~]+' , 1 , 11 ) into v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11
                    FROM DUAL ;
                    insert into studenti_test values (v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11);
                end;
            elsif(v_nume_tabel like 'P')then
                declare
                    p1 prieteni.id%type;
                    p2 prieteni.id_student1%type;
                    p3 prieteni.id_student2%type;
                    p4 prieteni.created_at%type;
                    p5 prieteni.updated_at%type;
                begin
                    SELECT REGEXP_SUBSTR ( v_sir , '[^~]+' , 1 , 1 ) 
                     , REGEXP_SUBSTR ( v_sir , '[^~]+' , 1 , 2 ) 
                     , REGEXP_SUBSTR ( v_sir , '[^~]+' , 1 , 3 ) 
                     , REGEXP_SUBSTR ( v_sir , '[^~]+' , 1 , 4 )
                     , REGEXP_SUBSTR ( v_sir , '[^~]+' , 1 , 5 ) into p1,p2,p3,p4,p5
                     FROM DUAL;
                     insert into prieteni_test values(p1,p2,p3,p4,p5);
                end;
            end if;
        elsif(v_sir like '*****') then
            v_ok:=0;
        end if;
        EXCEPTION  
        WHEN NO_DATA_FOUND THEN EXIT; 
        WHEN DUP_VAL_ON_INDEX THEN DBMS_OUTPUT.PUT_LINE('DUPLICATE');
        end;
    end loop;
end;
/

