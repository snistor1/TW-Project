create procedure build_useless_catalogue as
    v_cursor_id_curs number;
    v_cursor_creare_tabel number;
    v_cursor_note number;
    v_cursor_student number;
    v_cursor_inserare number;

    v_id_curs cursuri.id%type;
    v_id_student note.id_student%type;
    v_valoare note.valoare%type;
    v_data_notare note.data_notare%type;
    v_nume varchar2(15);
    v_prenume varchar2(30);
    v_nr_matricol varchar2(6);

    v_ok_id_curs integer;
    v_ok_creare_tabel integer;
    v_ok_note integer;
    v_ok_student integer;
    v_ok_inserare integer;
begin
    v_cursor_id_curs := DBMS_SQL.open_cursor;
    dbms_sql.parse(v_cursor_id_curs, 'select id from cursuri',DBMS_SQL.native);
    DBMS_SQL.DEFINE_COLUMN(v_cursor_id_curs,1,v_id_curs);
    v_ok_id_curs := dbms_sql.execute(v_cursor_id_curs);
    loop
        if dbms_sql.fetch_rows(v_cursor_id_curs) > 0 then
            dbms_sql.column_value(v_cursor_id_curs,1,v_id_curs);

            --aici creez tabelul
            v_cursor_creare_tabel := dbms_sql.open_cursor;
            dbms_sql.parse(v_cursor_creare_tabel,'create table "'||v_id_curs||
            '" (valoare number(2,0), data_notare date,nume varchar2(15), prenume varchar2(30),nr_matricol varchar2(6))',
            dbms_sql.native);
            v_ok_creare_tabel := dbms_sql.execute(v_cursor_creare_tabel);
            dbms_sql.close_cursor(v_cursor_creare_tabel);

            --aici incepe inserarea in tabel
            v_cursor_note := dbms_sql.open_cursor;
            dbms_sql.parse(v_cursor_note,'select id_student,valoare,data_notare from note where id_curs='||v_id_curs,DBMS_SQL.native);
            DBMS_SQL.DEFINE_COLUMN(v_cursor_note,1,v_id_student);
            DBMS_SQL.DEFINE_COLUMN(v_cursor_note,2,v_valoare);
            DBMS_SQL.DEFINE_COLUMN(v_cursor_note,3,v_data_notare);
            v_ok_note := dbms_sql.execute(v_cursor_note);
            loop
                if dbms_sql.fetch_rows(v_cursor_note) > 0 then
                    dbms_sql.column_value(v_cursor_note,1,v_id_student);
                    dbms_sql.column_value(v_cursor_note,2,v_valoare);
                    dbms_sql.column_value(v_cursor_note,3,v_data_notare);

                    --am nota,data_notarii, iar aici iau nume,prenume,nr_matricol
                    v_cursor_student := dbms_sql.open_cursor;
                    dbms_sql.parse(v_cursor_student,'select nume,prenume,nr_matricol from studenti where id='||v_id_student,DBMS_SQL.native);
                    dbms_sql.define_column(v_cursor_student,1,v_nume,15);
                    dbms_sql.define_column(v_cursor_student,2,v_prenume,30);
                    dbms_sql.define_column(v_cursor_student,3,v_nr_matricol,6);
                    v_ok_student := dbms_sql.execute(v_cursor_student);
                    if dbms_sql.fetch_rows(v_cursor_student) > 0 then
                        dbms_sql.column_value(v_cursor_student,1,v_nume);
                        dbms_sql.column_value(v_cursor_student,2,v_prenume);
                        dbms_sql.column_value(v_cursor_student,3,v_nr_matricol);
                    end if;
                    v_cursor_inserare := dbms_sql.open_cursor;
                    dbms_sql.parse(v_cursor_inserare,'insert into "'|| v_id_curs ||'" values('||v_valoare||
                    ','''||v_data_notare||''','''||v_nume||''','''||v_prenume||''','''||v_nr_matricol||''')',DBMS_SQL.native);
                    v_ok_inserare := dbms_sql.execute(v_cursor_inserare);
                    dbms_sql.close_cursor(v_cursor_student);
                    dbms_sql.close_cursor(v_cursor_inserare);
                else
                    exit;
                end if;
            end loop;
            dbms_sql.close_cursor(v_cursor_note);
        else 
            exit;
        end if;
    end loop;
    dbms_sql.close_cursor(v_cursor_id_curs);
end;
/

