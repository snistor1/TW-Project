create trigger ROLE_INC
  before insert
  on ROLES
  for each row
  BEGIN
    <<COLUMN_SEQUENCES>>
    BEGIN
      IF INSERTING AND :NEW.ID IS NULL THEN
        select nvl(max(id),0)+1 into :new.Id from roles;
      END IF;
    END COLUMN_SEQUENCES;
  end;
/

