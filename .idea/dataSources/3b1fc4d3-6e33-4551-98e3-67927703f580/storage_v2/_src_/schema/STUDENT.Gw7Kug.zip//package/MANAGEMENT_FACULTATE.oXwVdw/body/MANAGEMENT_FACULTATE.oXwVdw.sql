CREATE PACKAGE BODY management_facultate IS
    PROCEDURE varsta (p_data_nastere IN DATE) AS
    v_data_azi DATE := SYSDATE;
    p_ani NUMBER;
    p_luni NUMBER;
    p_zile NUMBER;
    BEGIN
    p_ani:=TRUNC(TRUNC(MONTHS_BETWEEN(v_data_azi, p_data_nastere))/12);
    p_luni:=TRUNC(MONTHS_BETWEEN(v_data_azi, p_data_nastere))-(p_ani*12);
    p_zile:= TRUNC(TO_NUMBER(v_data_azi -ADD_MONTHS(p_data_nastere , p_ani*12+ p_luni)));
    DBMS_OUTPUT.PUT_LINE('Ani: '||p_ani);
    DBMS_OUTPUT.PUT_LINE('Luni: '||p_luni);
    DBMS_OUTPUT.PUT_LINE('Zile: '||p_zile);
    END varsta;

    PROCEDURE afis_foaie_matricola(p_id IN studenti.id%TYPE)AS
    CURSOR lista_note IS SELECT * FROM note;
    v_titlu_curs cursuri.titlu_curs%TYPE;
    v_min note.valoare%TYPE:=10;
    v_max note.valoare%TYPE:=0;
    BEGIN
    FOR v_nota IN lista_note LOOP
     IF (v_nota.id_student=p_id)THEN
        SELECT titlu_curs INTO v_titlu_curs FROM cursuri WHERE id=v_nota.id_curs;
        DBMS_OUTPUT.PUT_LINE('La cursul: '||v_titlu_curs||' Nota: '||v_nota.valoare);
        IF(v_nota.valoare<v_min)THEN
          v_min:=v_nota.valoare;
        END IF;
        IF(v_nota.valoare>v_max)THEN
          v_max:=v_nota.valoare;
        END IF;
     END IF;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('Nota cea mai mica: '||v_min);
    DBMS_OUTPUT.PUT_LINE('Nota cea mai mare: '||v_max);
    END afis_foaie_matricola;

    FUNCTION medie_student (p_id studenti.id%TYPE)RETURN DOUBLE PRECISION  AS
    CURSOR lista_note IS SELECT * FROM note;
    v_sum DOUBLE PRECISION :=0;
    v_nr_note INTEGER :=0;
    v_avg DOUBLE PRECISION :=0;
    BEGIN
    FOR v_nota IN lista_note LOOP
    IF (v_nota.id_student=p_id)THEN
        v_nr_note:=v_nr_note+1;
        v_sum:=v_sum+v_nota.valoare;
    END IF;
    END LOOP;
    v_avg:=v_sum/v_nr_note;
    return v_avg;
    END medie_student;

    PROCEDURE afis_pozitie(p_id IN studenti.id%TYPE)AS
    CURSOR lista_studenti IS SELECT * FROM studenti ;
    v_grupa studenti.grupa%TYPE;
    v_an studenti.an%TYPE;
    v_medie DOUBLE PRECISION ;
    v_medie_coleg DOUBLE PRECISION;
    v_studenti_inainte INTEGER:=0;
    BEGIN
    v_medie:=medie_student(p_id);
    SELECT grupa, an INTO v_grupa, v_an FROM studenti WHERE id=p_id;
    FOR v_student IN lista_studenti LOOP
      IF(v_student.id!=p_id and v_student.grupa=v_grupa and v_student.an=v_an )THEN
        v_medie_coleg:=medie_student(v_student.id);
        IF( v_medie_coleg > v_medie )THEN
        v_studenti_inainte:= v_studenti_inainte+1;
        END IF;
       END IF;
    END LOOP;
    v_studenti_inainte:=v_studenti_inainte+1;
    DBMS_OUTPUT.PUT_LINE('Este al '||v_studenti_inainte||'-lea din grupa sa: '||v_grupa||' anul: '||v_an);
    END afis_pozitie;


    PROCEDURE afis_prieteni(p_id IN studenti.id%TYPE)AS
    CURSOR lista_prieteni IS SELECT * FROM prieteni;
    CURSOR lista_studenti IS SELECT * FROM studenti;
    v_nume studenti.nume%TYPE;
    v_prenume studenti.prenume%TYPE;
    v_nr_prieteni int:=0;
    BEGIN
    DBMS_OUTPUT.PUT_LINE('Prietenii sai:');
    FOR v_prieteni IN lista_prieteni LOOP
       IF(v_prieteni.id_student1=p_id and v_prieteni.id_student2!=p_id)THEN
         SELECT nume, prenume INTO v_nume, v_prenume FROM studenti WHERE id=v_prieteni.id_student2;
         DBMS_OUTPUT.PUT_LINE(v_nume||' '||v_prenume);
         v_nr_prieteni:=v_nr_prieteni+1;
       ELSE IF(v_prieteni.id_student2=p_id and v_prieteni.id_student1!=p_id)THEN
         SELECT nume, prenume INTO v_nume, v_prenume FROM studenti WHERE id=v_prieteni.id_student1;
         DBMS_OUTPUT.PUT_LINE(v_nume||' '||v_prenume);
         v_nr_prieteni:=v_nr_prieteni+1;
         END IF;
       END IF;
    END LOOP;
     DBMS_OUTPUT.PUT_LINE('Are '||v_nr_prieteni||' prieteni');
    END afis_prieteni;

    FUNCTION cauta_nr_matricol (p_nr_matricol studenti.nr_matricol%TYPE)return NUMBER AS
    CURSOR lista_studenti IS SELECT * FROM studenti;
    BEGIN
    FOR v_student IN lista_studenti LOOP
      IF (v_student.nr_matricol=p_nr_matricol)THEN
         return 1;
      END IF;
    END LOOP;
    return 0;
    END cauta_nr_matricol;

    PROCEDURE adauga_student (p_nume studenti.nume%TYPE,p_prenume studenti.prenume%TYPE ) AS
    v_id studenti.id%TYPE;
    v_nr_matricol studenti.nr_matricol%TYPE;
    v_an studenti.an%TYPE;
    v_grupa studenti.grupa%TYPE := 'A5';
    v_id_nota note.id%TYPE;
    v_id_curs cursuri.id%TYPE;
    v_valoare note.valoare%TYPE;
    v_este NUMBER(3);
    v_contor INTEGER := 0;
    BEGIN
    SELECT (MAX(id)+1) INTO v_id FROM studenti;
    SELECT ROUND(DBMS_RANDOM.value(1,3)) INTO v_an FROM dual;
    SELECT TO_CHAR(TO_CHAR((ROUND(DBMS_RANDOM.value(1,9))))||TO_CHAR(ROUND(DBMS_RANDOM.value(0,9)))||TO_CHAR(ROUND(DBMS_RANDOM.value(0,9)))||
    TO_CHAR((DBMS_RANDOM.string('U',1)))||TO_CHAR((DBMS_RANDOM.string('U',1)))||TO_CHAR(ROUND(DBMS_RANDOM.value(0,9))))
    INTO v_nr_matricol FROM dual;
    while(cauta_nr_matricol(v_nr_matricol)=1)LOOP
    SELECT TO_CHAR(TO_CHAR((ROUND(DBMS_RANDOM.value(1,9))))||TO_CHAR(ROUND(DBMS_RANDOM.value(0,9)))||TO_CHAR(ROUND(DBMS_RANDOM.value(0,9)))||
    TO_CHAR((DBMS_RANDOM.string('U',1)))||TO_CHAR((DBMS_RANDOM.string('U',1)))||TO_CHAR(ROUND(DBMS_RANDOM.value(0,9))))
    INTO v_nr_matricol FROM dual;
    END LOOP;
    INSERT INTO studenti (id,nr_matricol,nume,prenume,an,grupa) VALUES (v_id,v_nr_matricol,p_nume,p_prenume,v_an,v_grupa);
     for v_contor IN 1..5 LOOP--introducem 5 note
      SELECT (MAX(id)+1) INTO v_id_nota FROM note;
      SELECT * INTO v_id_curs FROM ( SELECT id FROM  cursuri WHERE an<=v_an ORDER BY DBMS_RANDOM.VALUE) WHERE  rownum <=1;
      SELECT ROUND(DBMS_RANDOM.value(4,9)) INTO v_valoare FROM dual;
      INSERT INTO note(id,ID_STUDENT,ID_CURS,valoare) VALUES (v_id_nota,v_id,v_id_curs,v_valoare);
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('Introdus');
    END adauga_student;

    PROCEDURE stergere_student( p_nume studenti.nume%TYPE,p_prenume studenti.prenume%TYPE )AS
    v_id studenti.id%TYPE;
    BEGIN
    SELECT id INTO v_id FROM studenti WHERE nume=p_nume and prenume=p_prenume;
    DELETE FROM prieteni where id_student1=v_id or id_student2=v_id;
    DELETE FROM note where id_student=v_id;
    DELETE FROM studenti where id=v_id;
    DBMS_OUTPUT.PUT_LINE('Sters');
    END stergere_student;

    PROCEDURE afis_informatii ( p_nume studenti.nume%TYPE,p_prenume studenti.prenume%TYPE )AS
    v_nr_matricol studenti.nr_matricol%TYPE;
    v_id studenti.id%TYPE;
    v_data_nastere studenti.data_nastere%TYPE;
    v_medie DOUBLE PRECISION;
    v_grupa studenti.grupa%TYPE;
    v_an studenti.grupa%TYPE;
    BEGIN
    SELECT id INTO v_id FROM studenti WHERE nume=p_nume and prenume=p_prenume;
    DBMS_OUTPUT.PUT_LINE('Studentul cu numele: '||p_nume||' '||p_prenume);
    SELECT nr_matricol,data_nastere,grupa,an INTO v_nr_matricol,v_data_nastere,v_grupa,v_an FROM studenti WHERE id=v_id;
    DBMS_OUTPUT.PUT_LINE('Numarul matricol: '||v_nr_matricol);
    DBMS_OUTPUT.PUT_LINE('Foaie Matricola: ');
    afis_foaie_matricola(v_id);
    v_medie:=medie_student(v_id);
    DBMS_OUTPUT.PUT_LINE('Media: '||v_medie);
    DBMS_OUTPUT.PUT_LINE('Varsta: ');
    varsta(v_data_nastere);
    afis_pozitie(v_id);
    afis_prieteni(v_id);
    END afis_informatii;
END management_facultate;
/

