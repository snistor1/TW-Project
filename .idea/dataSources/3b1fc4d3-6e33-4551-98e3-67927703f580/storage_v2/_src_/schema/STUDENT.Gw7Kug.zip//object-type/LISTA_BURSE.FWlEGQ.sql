CREATE type lista_burse as table of chestie
/

