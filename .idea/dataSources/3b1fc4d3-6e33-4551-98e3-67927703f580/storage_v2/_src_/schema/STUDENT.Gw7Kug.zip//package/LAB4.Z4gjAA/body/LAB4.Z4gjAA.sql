CREATE PACKAGE BODY LAB4 IS
    PROCEDURE marire_bursa(v_alesi alesi) IS
    bursa_noua studenti.bursa%type;
    temp unicorn := unicorn();
    BEGIN
        for i in v_alesi.first..v_alesi.last loop
            for v_student in lista_studenti loop
                if(v_alesi(i).v_id=v_student.id) then
                   if(v_student.bursa is null) then
                    update studenti set bursa = 100 + 100 * (v_alesi(i).v_procentaj/100) where id=v_student.id;
                    else update studenti set bursa = bursa + bursa * (v_alesi(i).v_procentaj/100) where id=v_student.id;
                   end if;
                    select bursa into bursa_noua from studenti where id=v_student.id;
                    if(v_student.istoric is not null) then
                        select istoric into temp from studenti where id=v_student.id;
                    end if;
                    temp.extend;
                    temp(temp.count) := chestie(bursa_noua, sysdate);
                    update studenti set istoric=temp where id=v_student.id;
                end if;
            end loop;
        end loop;
    END marire_bursa;
    PROCEDURE afisare_schimbari is
    begin
        for v_student in lista_studenti loop
            if(v_student.istoric is not null) then
                dbms_output.put_line(v_student.nume || ' ' || v_student.prenume);
                for i in 1..v_student.istoric.count loop
                    dbms_output.put_line('Bursa: ' || v_student.istoric(i).v_bursa || ' la data de ' || v_student.istoric(i).v_data);
                end loop;
            end if;
        end loop;
    end;
END LAB4;
/

