CREATE PACKAGE management_facultate IS
    PROCEDURE afis_informatii ( p_nume studenti.nume%TYPE,p_prenume studenti.prenume%TYPE );
    PROCEDURE adauga_student (p_nume studenti.nume%TYPE, p_prenume studenti.prenume%TYPE);
    PROCEDURE stergere_student( p_nume studenti.nume%TYPE,p_prenume studenti.prenume%TYPE );
END management_facultate;
/

