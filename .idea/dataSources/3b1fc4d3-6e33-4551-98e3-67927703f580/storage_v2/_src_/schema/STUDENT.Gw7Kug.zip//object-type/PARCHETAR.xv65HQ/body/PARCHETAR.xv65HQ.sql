CREATE type body parchetar as
    overriding member procedure afiseaza_salariu is
    v_rezultat int;
    begin
        v_rezultat := self.salariu * self.vechime_in_ani + self.salariu_auxiliar * self.vechime_in_ani;
        v_rezultat := v_rezultat * 10;
        dbms_output.put_line('Parchetarii sunt bogati. Dovada: ' || v_rezultat || ' de euro.');
    end afiseaza_salariu;
end;
/

