CREATE PROCEDURE prietenieMisterioasa as
v_count1 int := 0;
v_suma1 number(5,0) := 0;
v_count2 int := 0;
v_suma2 number(5,0) := 0;
Cursor lista_prieteni is
select id_student1,id_student2 from prieteni;
begin
    for v_prietenie in lista_prieteni loop
        v_count1 := 0;
        v_suma1 := 0;
        for v_valoare in (SELECT valoare from note where id_student=v_prietenie.id_student1) loop
            v_suma1 := v_suma1+v_valoare.valoare;
            v_count1 := v_count1+1;
        END LOOP;
        v_count2 := 0;
        v_suma2 := 0;
        for v_valoare in (SELECT valoare from note where id_student=v_prietenie.id_student2) loop
            v_suma2 := v_suma2+v_valoare.valoare;
            v_count2 := v_count2+1;
        END LOOP;
        if(trunc(v_suma1/v_count1)=trunc(v_suma2/v_count2)) then
            dbms_output.put_line(v_prietenie.id_student1 || ' ' ||v_prietenie.id_student2);
        end if;
    end loop;
end;
/

