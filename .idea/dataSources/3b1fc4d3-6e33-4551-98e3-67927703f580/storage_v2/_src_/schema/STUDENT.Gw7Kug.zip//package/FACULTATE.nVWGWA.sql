CREATE package facultate is
    cursor lista_cursuri is select * from cursuri;
    cursor lista_note is select * from note;
    cursor lista_studenti is select * from studenti;
    cursor lista_prieteni is select * from prieteni;
    PROCEDURE adauga_student (nume studenti.nume%type, prenume studenti.prenume%type);
    PROCEDURE sterge_student (nr_matr studenti.nr_matricol%type);
    PROCEDURE get_info(id_stud studenti.id%type);
end facultate;
/

