CREATE type chestie as object(v_bursa number(6,2), v_data date);
/

