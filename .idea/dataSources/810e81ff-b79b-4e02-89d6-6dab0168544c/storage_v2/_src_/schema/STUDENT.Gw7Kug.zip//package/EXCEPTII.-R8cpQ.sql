CREATE package exceptii is
    prea_barosan exception;
end exceptii;
/

