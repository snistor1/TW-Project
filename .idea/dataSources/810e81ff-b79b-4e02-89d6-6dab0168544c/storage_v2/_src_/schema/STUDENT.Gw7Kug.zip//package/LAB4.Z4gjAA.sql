CREATE PACKAGE LAB4 IS
    type ales is record(v_id studenti.id%type, v_procentaj number(3));
    type alesi is table of ales;
    cursor lista_studenti is select * from studenti;
    PROCEDURE marire_bursa(v_alesi alesi);
    PROCEDURE afisare_schimbari;
END LAB4;
/

