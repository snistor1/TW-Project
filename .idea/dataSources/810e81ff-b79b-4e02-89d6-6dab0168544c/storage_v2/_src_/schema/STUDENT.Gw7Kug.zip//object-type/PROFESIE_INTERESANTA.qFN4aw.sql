CREATE type profesie_interesanta as object
(denumire varchar2(20),
 salariu int,
 vechime_in_ani int,
 not final member procedure afiseaza_salariu,
 final member procedure salariu_in_viitor(viitor int),
 member procedure salariu_in_viitor(mesaj varchar2), --pentru 4
 map member function vechime_sortare return int, --pentru 2
 constructor function profesie_interesanta(denumire varchar2,salariu int,vechime_in_ani int)
    return self as result
) not final;
/

