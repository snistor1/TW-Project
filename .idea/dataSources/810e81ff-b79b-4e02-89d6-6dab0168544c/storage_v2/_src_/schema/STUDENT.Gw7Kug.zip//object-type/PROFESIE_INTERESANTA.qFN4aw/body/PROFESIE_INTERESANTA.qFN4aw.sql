CREATE type body profesie_interesanta as
    not final member procedure afiseaza_salariu is
    v_rezultat int;
    begin
        v_rezultat := self.salariu * self.vechime_in_ani;
        dbms_output.put_line('Salariu curent: ' || v_rezultat);
    end afiseaza_salariu;

    final member procedure salariu_in_viitor(viitor int) is
    v_rezultat int;
    begin
        v_rezultat := self.salariu * (self.vechime_in_ani + viitor);
        dbms_output.put_line('Salariul peste ' || viitor || ' ani va fi: ' || v_rezultat);
    end salariu_in_viitor;

    member procedure salariu_in_viitor(mesaj varchar2) is
    v_rezultat int;
    begin
        v_rezultat := self.salariu * (self.vechime_in_ani + 10);
        dbms_output.put_line(mesaj);
        dbms_output.put_line('Salariul peste 10 ani va fi: ' || v_rezultat);
    end salariu_in_viitor;

    map member function vechime_sortare
    return int as
    begin
        return self.vechime_in_ani;
    end;

    constructor function profesie_interesanta(denumire varchar2,salariu int,vechime_in_ani int)
        return self as result
        as
        begin
            self.denumire := denumire;
            self.salariu := salariu;
            self.vechime_in_ani := vechime_in_ani;
            return;
        end;  
end;
/

