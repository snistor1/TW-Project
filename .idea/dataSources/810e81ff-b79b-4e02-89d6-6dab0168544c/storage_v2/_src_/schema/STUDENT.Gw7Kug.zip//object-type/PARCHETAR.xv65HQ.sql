CREATE type parchetar under profesie_interesanta
(
    salariu_auxiliar int,
    overriding member procedure afiseaza_salariu
    --overriding member procedure salariu_in_viitor(viitor int)
)
/

