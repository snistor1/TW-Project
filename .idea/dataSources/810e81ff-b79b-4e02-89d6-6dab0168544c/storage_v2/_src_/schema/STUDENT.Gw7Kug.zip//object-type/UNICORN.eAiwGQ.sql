CREATE type unicorn is table of chestie;
/

