CREATE package body facultate is
    PROCEDURE calculeazaVarsta(dataNastere date,v_rezultat out varchar2) is
    BEGIN
        v_rezultat := trunc(months_between(sysdate,dataNastere)/12)||' ani '|| 
        floor(to_number(months_between(sysdate,dataNastere)-(trunc(months_between(sysdate,dataNastere)/12))*12))||' luni '|| 
        floor(to_number(sysdate-add_months(dataNastere,trunc(months_between(sysdate,dataNastere)))))||' zile. ';
    END calculeazaVarsta;

    PROCEDURE adauga_student (nume studenti.nume%type, prenume studenti.prenume%type) 
       IS
       v_id studenti.id%type;
       v_nr_matricol studenti.nr_matricol%type;
       v_an studenti.an%type;
       v_grupa studenti.grupa%type;
       v_bursa studenti.bursa%type;
       v_nr number(3);
       v_contor number(3);
       v_nota note.valoare%type;
       v_id_nota note.id%type;
       BEGIN
       select max(id)+1 into v_id from studenti;                            --iau id-ul maxim existent si il incrementez
       select dbms_random.string('X', 6) str into v_nr_matricol from dual;      
       select count(*) into v_nr from studenti where nr_matricol=v_nr_matricol;
       while(v_nr!=0) loop                                                  --cat timp nr_matricol exista deja, generez
            select dbms_random.string('X', 6) str into v_nr_matricol from dual;
            select count(*) into v_nr from studenti where nr_matricol=v_nr_matricol;
       end loop;
       select dbms_random.value(1,3) num into v_an from dual;               --nr random intre 1 si 3 (anul)
       select dbms_random.value(1,6) num into v_contor from dual;
       if(mod(v_contor,2)=0) then
        v_grupa := concat('A',to_char(v_contor));
        else 
            v_grupa := concat('B',to_char(v_contor));
        end if;
        v_bursa := length(nume)*length(prenume);
        insert into studenti(id,nr_matricol,nume,prenume,an,grupa,bursa) values(v_id,v_nr_matricol,nume,prenume,v_an,v_grupa,v_bursa); --inserez studentul
        for v_curs in lista_cursuri loop
            if(v_curs.an <= v_an) then
                select dbms_random.value(4,10) num into v_nota from dual;
                select max(id)+1 into v_id_nota from note;
                insert into note(id,id_student,id_curs,valoare) values(v_id_nota,v_id,v_curs.id,v_nota);
            end if;
        end loop;
    END adauga_student;

    PROCEDURE sterge_student (nr_matr studenti.nr_matricol%type) IS
    v_id studenti.id%type;
    BEGIN
        select id into v_id from studenti where nr_matricol=nr_matr;
        delete from note where id_student=v_id;
        delete from prieteni where id_student1=v_id;
        delete from prieteni where id_student2=v_id;
        delete from studenti where nr_matricol=nr_matr;
    END sterge_student;

    PROCEDURE get_info(id_stud studenti.id%type) is
    v_nr_matricol studenti.nr_matricol%type;
    v_count number(2);
    v_suma number(5);
    v_media double precision;
    v_varsta varchar2(100);
    v_data_nastere studenti.data_nastere%type;
    v_titlu_curs cursuri.titlu_curs%type;
    v_grupa studenti.grupa%type;
    v_an studenti.an%type;
    v_rank number(2) := 1;
    v_media_aux double precision;
    v_nume_prieten studenti.nume%type;
    v_prenume_prieten studenti.prenume%type;
    BEGIN
        select nr_matricol into v_nr_matricol from studenti where id=id_stud;
        dbms_output.put_line('Nr. maricol: ' || v_nr_matricol);

        v_count := 0;
        v_suma := 0;
        for v_valoare in (select valoare from note where id_student=id_stud) loop
            v_suma := v_suma + v_valoare.valoare;
            v_count := v_count + 1;
        end loop;
        v_media := v_suma/v_count;
        dbms_output.put_line('Media: ' || v_media);

        dbms_output.put_line('-----Foaia matricola-----');
        for v_nota in lista_note loop
            if(v_nota.id_student=id_stud) then
                select titlu_curs into v_titlu_curs from cursuri where id=v_nota.id_curs;
                dbms_output.put_line(v_titlu_curs || ' ' || v_nota.valoare);
            end if;
        end loop;

        select grupa into v_grupa from studenti where id=id_stud;
        select an into v_an from studenti where id=id_stud;
        for v_student in lista_studenti loop
            if(v_student.grupa=v_grupa and v_student.an=v_an) then
                v_count := 0;
                v_suma := 0;
                for v_valoare in (SELECT valoare from note where id_student=v_student.id) loop
                    v_suma:=v_suma+v_valoare.valoare;
                    v_count:=v_count+1;
                END LOOP;
                v_media_aux := v_suma/v_count;
                if(v_media<v_media_aux) then
                    v_rank := v_rank+1;
                end if;
            end if;
        end loop;
        dbms_output.put_line('Rank in grupa: ' || v_rank);

        select data_nastere into v_data_nastere from studenti where id=id_stud;
        calculeazaVarsta(v_data_nastere,v_varsta);
        dbms_output.put_line('Varsta: ' || v_varsta);

        dbms_output.put_line('-----Prieteni-----');
        for v_prieten in lista_prieteni loop
            if(v_prieten.id_student1=id_stud)then
                select nume,prenume into v_nume_prieten,v_prenume_prieten from studenti where id=v_prieten.id_student2;
                dbms_output.put_line(v_nume_prieten|| ' ' || v_prenume_prieten);
            elsif(v_prieten.id_student2=id_stud)then
                select nume,prenume into v_nume_prieten,v_prenume_prieten from studenti where id=v_prieten.id_student1;
                dbms_output.put_line(v_nume_prieten|| ' ' || v_prenume_prieten);
            end if;
        end loop;
    END get_info;
end facultate;
/

