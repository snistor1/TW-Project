CREATE type burse_smechere as table of lab4.chestie;
/

