CREATE procedure barosan(v_id studenti.id%type) as
bursa_noua studenti.bursa%type;
exceptie number(1) := 0;
begin
    update studenti set bursa_trecuta=nvl(bursa,0) where id=v_id;
    select nvl(bursa,0) into bursa_noua from studenti where id=v_id;
    bursa_noua := bursa_noua +1000;
    if bursa_noua > 3000 then
        bursa_noua := 3000;
        exceptie := 1;
    end if;
    update studenti set bursa=bursa_noua where id=v_id;
    if(exceptie=1) then
        raise exceptii.prea_barosan;
    end if;
end barosan;
/

