CREATE procedure inseram_si_ne_distram(v_id studenti.id%type) as
counter number(2);
student_deja_existent exception;
v_nume studenti.nume%type;
v_prenume studenti.prenume%type;
begin
    select count(*) into counter from erasmus where nr_matricol=(select nr_matricol from studenti where id=v_id);
    if counter != 0 then
        raise student_deja_existent;
    end if;
    insert into erasmus select nr_matricol,nume,prenume,id from studenti where id=v_id;
    select nume,prenume into v_nume,v_prenume from studenti where id=v_id;
    dbms_output.put_line('Student inserat cu succes: ' || v_nume || ' ' || v_prenume);
exception
when student_deja_existent then
    select nume,prenume into v_nume,v_prenume from studenti where id=v_id;
    dbms_output.put_line('Student deja existent. Nu a putut fi inserat: ' || v_nume || ' ' || v_prenume);
end inseram_si_ne_distram;
/

