create trigger INSEREAZA_PARCHETAR
  instead of insert
  on CONEXIUNE_MAGICA
  for each row
  begin
    insert into parchetari values(:new.id_parchetar,:new.nume,:new.varsta);
    insert into unelte values(:new.id_unealta,:new.denumire,:new.id_parchetar);
end;
/

