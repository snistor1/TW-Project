create view CONEXIUNE_MAGICA as
  select p.id_parchetar,p.nume,p.varsta,
u.id_unealta,u.denumire from parchetari p join unelte u on p.ID_PARCHETAR=u.ID_POSESOR
/

