create trigger UPGRADEAZA_PARCHTAR
  instead of update
  on CONEXIUNE_MAGICA
  for each row
  begin
    update parchetari
    set nume = :new.nume
    where id_parchetar= :old.id_parchetar;
end;
/

