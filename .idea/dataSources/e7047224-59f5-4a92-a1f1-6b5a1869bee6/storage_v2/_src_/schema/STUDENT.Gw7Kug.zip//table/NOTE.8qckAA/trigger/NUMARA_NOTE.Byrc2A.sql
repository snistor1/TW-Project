create trigger NUMARA_NOTE
  before update of VALOARE
  on NOTE
  for each row
  begin
    if(:old.valoare>=:new.valoare) then
        :new.valoare := :old.valoare;
    else
        update note_modificate set numar=numar+1 where id_modif=(select max(id_modif) from note_modificate);
    end if;
end;
/

