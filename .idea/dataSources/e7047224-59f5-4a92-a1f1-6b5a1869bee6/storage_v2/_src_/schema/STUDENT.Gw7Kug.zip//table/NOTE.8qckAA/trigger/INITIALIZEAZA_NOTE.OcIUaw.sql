create trigger INITIALIZEAZA_NOTE
  before update of VALOARE
  on NOTE
  begin
    insert into note_modificate values((select nvl(max(id_modif),0)+1 from note_modificate),0);
end;
/

